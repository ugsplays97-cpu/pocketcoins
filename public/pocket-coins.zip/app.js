(() => {
  const api = globalThis.browser ?? globalThis.chrome;
  const store = window.PC_STORE;
  const IS_WEB = store.mode !== "extension";
  const $ = (id) => document.getElementById(id);
  const esc = window.PC_ESC;
  const GAMES = window.GAMES;
  const IS_WIN = new URLSearchParams(location.search).has("win");
  if (IS_WIN || IS_WEB) document.body.classList.add("win");
  if (IS_WEB) document.body.classList.add("web");
  // Opened inside the extension's popup (live copy from the website).
  const IN_EXT = IS_WEB && new URLSearchParams(location.search).has("ext") && window.parent !== window;
  if (IN_EXT && !IS_WIN) document.body.classList.add("ext");

  const rid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  const VIEWS = ["home", "setup", "waiting", "duel", "over", "ownerGate", "owner"];
  const show = (v) => VIEWS.forEach((id) => ($(id).hidden = id !== v));

  let coins = 100;
  let me = { id: "", name: "" };
  let lobby = null, lobbyReady = false;
  let online = {}; // id -> { name, coins, busy }
  let duel = null; // { id, game, bet, foeId, foeName, side, ended, handle }
  let outgoing = null; // { id, to, toName, game, bet, timer }
  const invites = new Map(); // id -> { from, fromName, game, bet, timer }
  let target = null, pickedGame = "walls";
  // Owner perks (set from the secret owner panel)
  let owner = { luck: 0, shield: false, wide: false, crown: false };
  // Luck an owner gave this player from their owner panel (-100..100).
  let given = 0;
  const RULES = window.PC_RULES;
  const clampLuck = RULES.clampLuck;
  let skills = [];
  let skillLv = {}; // skill id -> level (1..3)
  let inv = []; // item ids in the bag
  let betItem = null; // index into inv being bet on the next flip
  let chips = 0, casino = {}, casinoAt = 0; // casino tycoon
  const perks = () => RULES.perks(skills, skillLv);
  const cfmt = (n) => { n = Math.floor(+n || 0); return n >= 1e6 ? (n / 1e6).toFixed(1).replace(/\.0$/, "") + "M" : n >= 1e4 ? (n / 1e3).toFixed(1).replace(/\.0$/, "") + "k" : n.toLocaleString(); };
  const luck = () => clampLuck(owner.luck + given + perks().luck);
  const luckLabel = (n) => n >= 100 ? "Always win" : n <= -100 ? "Always lose" : n > 0 ? `+${n}%` : n < 0 ? `${n}%` : "Normal";
  // Free coins can be claimed once a minute.
  let bonusAt = 0;

  // ---------- coins ----------
  function setCoins(n) {
    coins = Math.max(0, Math.floor(n));
    $("bal").textContent = coins;
    store.set({ coins });
    updBonus();
    track();
    submitScore();
  }
  function notice(html) {
    $("notice").innerHTML = html;
    $("notice").hidden = false;
    clearTimeout(notice.t);
    notice.t = setTimeout(() => ($("notice").hidden = true), 5000);
  }

  // ---------- tabs ----------
  function tab(name) {
    document.querySelectorAll(".tabs button").forEach((b) => b.classList.toggle("on", b.dataset.tab === name));
    $("flip").hidden = name !== "flip";
    $("players").hidden = name !== "players";
    $("top").hidden = name !== "top";
    $("skills").hidden = name !== "skills";
    $("casino").hidden = name !== "casino";
    $("bag").hidden = name !== "bag";
    if (name === "bag") renderBag();
    if (name === "casino") renderCasino();
    if (name === "top") loadTop();
    if (name === "skills") renderSkills();
  }
  document.querySelectorAll(".tabs button").forEach((b) => (b.onclick = () => tab(b.dataset.tab)));

  // ---------- flip ----------
  const updMult = () => {
    const c = +$("chance").value;
    $("chanceTxt").textContent = c + "%";
    $("mult").textContent = "×" + (100 / c).toFixed(2);
  };
  $("chance").oninput = updMult;
  document.querySelectorAll("[data-bet]").forEach((b) => (b.onclick = () => {
    const cur = Math.floor(+$("bet").value) || 1;
    const v = { half: Math.floor(cur / 2), double: cur * 2, max: coins }[b.dataset.bet];
    $("bet").value = Math.max(1, Math.min(v, Math.max(coins, 1)));
  }));
  $("spin").onclick = () => {
    if (betItem != null) return flipItem();
    const raw = $("bet").value.trim();
    const bet = Math.floor(+raw), c = +$("chance").value;
    const res = $("flipResult");
    if (secretStep(raw)) return;
    if (!(bet >= 1) || bet > coins) { res.innerHTML = `<span class="lose-txt">Not enough coins</span>`; return; }
    $("spin").disabled = true;
    const coin = $("flipCoin");
    coin.classList.remove("spin"); void coin.offsetWidth; coin.classList.add("spin");
    res.textContent = "";
    setTimeout(() => {
      const odds = Math.min(100, RULES.flipOdds(c, luck()) * (1 + perks().winBoost));
      if (Math.random() * 100 < odds) {
        const win = Math.floor(((bet * 100) / c - bet) * (1 + perks().flipBonus));
        setCoins(coins + win);
        res.innerHTML = `<span class="win-txt">+${win} coins</span>`;
      } else {
        if (owner.shield) res.innerHTML = `<span class="muted">Lost, but your coins are safe</span>`;
        else {
          const back = Math.floor(bet * perks().flipRefund);
          setCoins(coins - bet + back);
          res.innerHTML = `<span class="lose-txt">−${bet - back} coins</span>` + (back ? ` <span class="muted small">(${back} back)</span>` : "");
        }
      }
      $("spin").disabled = false;
    }, 700);
  };
  // ---------- inventory ----------
  const rarName = (r) => (RULES.RARITIES.find((x) => x.id === r) || {}).name || r;
  function setInv(next) { inv = next; store.set({ inv }); }
  function renderBag() {
    const worth = inv.reduce((n, id) => n + ((RULES.item(id) || {}).value || 0), 0);
    $("bagWorth").textContent = cfmt(worth);
    const counts = {};
    inv.forEach((id) => (counts[id] = (counts[id] || 0) + 1));
    const ids = Object.keys(counts).sort((a, b) => RULES.item(b).value - RULES.item(a).value);
    $("bagList").innerHTML = ids.length ? ids.map((id) => {
      const it = RULES.item(id);
      return `<div class="biz r-${it.rarity} bag-item"><span class="biz-ic">${it.icon}</span><div class="biz-main"><b>${it.name}</b> <span class="muted small">×${counts[id]}</span>
        <div class="small rar">${rarName(it.rarity)} · ${cfmt(it.value)} 🪙</div></div>
        <button class="btn-ghost sm" data-sell="${id}">Sell</button><button class="btn-gold sm" data-ibet="${id}">Bet</button></div>`;
    }).join("") : `<div class="empty">Your bag is empty. Open packs in the Casino tab.</div>`;
    $("bagList").querySelectorAll("[data-sell]").forEach((b) => (b.onclick = () => {
      const i = inv.indexOf(b.dataset.sell); if (i < 0) return;
      const it = RULES.item(b.dataset.sell);
      setInv(inv.filter((_, k) => k !== i)); setCoins(coins + it.value); renderBag();
    }));
    $("bagList").querySelectorAll("[data-ibet]").forEach((b) => (b.onclick = () => { pickBetItem(inv.indexOf(b.dataset.ibet)); tab("flip"); }));
  }
  function pickBetItem(i) {
    betItem = i >= 0 && inv[i] ? i : null;
    const it = betItem != null && RULES.item(inv[betItem]);
    $("itemBet").hidden = !it;
    $("coinBet").hidden = !!it;
    if (it) {
      $("itemBet").innerHTML = `<span class="biz-ic">${it.icon}</span><div class="biz-main"><b>Betting ${it.name}</b><div class="small muted">Worth ${cfmt(it.value)} 🪙 — win coins, or lose the item</div></div><button id="itemBetX" class="btn-ghost sm">✕</button>`;
      $("itemBetX").onclick = () => pickBetItem(-1);
    }
  }
  function flipItem() {
    const id = inv[betItem], it = RULES.item(id), c = +$("chance").value, res = $("flipResult");
    if (!it) return pickBetItem(-1);
    $("spin").disabled = true;
    const coin = $("flipCoin");
    coin.classList.remove("spin"); void coin.offsetWidth; coin.classList.add("spin");
    res.textContent = "";
    setTimeout(() => {
      const odds = Math.min(100, RULES.flipOdds(c, luck()) * (1 + perks().winBoost));
      if (Math.random() * 100 < odds) {
        const win = Math.floor(((it.value * 100) / c - it.value) * (1 + perks().flipBonus));
        setCoins(coins + win);
        res.innerHTML = `<span class="win-txt">Kept ${it.icon} and won +${cfmt(win)} coins</span>`;
      } else if (owner.shield) {
        res.innerHTML = `<span class="muted">Lost, but your ${it.name} is safe</span>`;
      } else {
        setInv(inv.filter((_, k) => k !== betItem));
        res.innerHTML = `<span class="lose-txt">Lost your ${it.icon} ${it.name}</span>`;
      }
      pickBetItem(inv.indexOf(id));
      $("spin").disabled = false;
    }, 700);
  }

  function updBonus() {
    const b = $("bonus");
    b.hidden = coins >= 10;
    clearTimeout(updBonus.t);
    if (b.hidden) return;
    const left = RULES.bonusLeft(bonusAt, Date.now(), perks().bonusWait);
    b.disabled = left > 0;
    b.textContent = left > 0 ? `Free ${perks().bonusAmount} coins in ${left}s` : `Out of coins? Claim ${perks().bonusAmount}`;
    if (left > 0) updBonus.t = setTimeout(updBonus, 1000);
  }
  $("bonus").onclick = () => {
    if (coins >= 10 || RULES.bonusLeft(bonusAt, Date.now(), perks().bonusWait) > 0) return updBonus();
    bonusAt = Date.now();
    store.set({ bonusAt });
    const amt = perks().bonusAmount;
    setCoins(coins + amt);
    $("flipResult").innerHTML = `<span class="win-txt">+${amt} free coins</span>`;
  };


  // ---------- skill tree ----------
  let skSel = null;
  const skBoost = (s) => { const m = s.desc.match(/([\d.]+%)|every (\d+s)|gives (\d+)/); return m ? (m[1] ? "+" + m[1] : m[2] ? m[2] : m[3]) : ""; };
  function renderSkills() {
    const branches = [...new Set(RULES.SKILLS.map((s) => s.branch))];
    $("skillTree").innerHTML = `<div class="hive">` + branches.map((br, i) => `<div class="hive-col${i % 2 ? " down" : ""}"><div class="hive-label">${br}</div>` +
      RULES.SKILLS.filter((s) => s.branch === br).map((s) => {
        const own = skills.includes(s.id), open = !s.req || skills.includes(s.req);
        const price = RULES.skillChipCost(s), lv = RULES.level(skillLv, s.id);
        const cls = own ? "own" : open ? (chips >= price ? "buy" : "open") : "locked";
        return `<button class="hex ${cls}${skSel === s.id ? " sel" : ""}" data-sk="${s.id}" title="${s.name}"><span><i>${open || own ? s.icon : "🔒"}</i><em>${skBoost(s)}</em><small>${own ? "★".repeat(lv) : cfmt(price) + "◆"}</small></span></button>`;
      }).join("") + `</div>`).join("") + `</div><div id="skInfo" class="sk-info"></div>`;
    $("skillTree").querySelectorAll("[data-sk]").forEach((b) => (b.onclick = () => { skSel = b.dataset.sk; $("skStatus").textContent = ""; renderSkills(); }));
    const s = RULES.SKILLS.find((k) => k.id === skSel);
    if (!s) { $("skInfo").innerHTML = `<span class="muted small">Tap a cell to see the skill. Each one unlocks the cell below it.</span>`; return; }
    const own = skills.includes(s.id), open = !s.req || skills.includes(s.req);
    const req = s.req && RULES.SKILLS.find((k) => k.id === s.req);
    const price = RULES.skillChipCost(s), lv = RULES.level(skillLv, s.id), up = RULES.upgradeCost(s.id, skillLv);
    $("skInfo").innerHTML = `<div class="sk-head"><span class="sk-ic">${s.icon}</span><div><b>${s.name}</b><div class="small muted">${s.branch}${own ? ` · Level ${lv}/${RULES.MAX_LEVEL}` : ""}</div></div></div>
      <div>${s.desc}${own && lv > 1 ? ` <span class="win-txt small">×${RULES.levelMult(lv)}</span>` : ""}</div>` +
      (own ? (up == null ? `<div class="win-txt small">Max level</div>` : `<button id="skUp" class="btn-gold" ${chips >= up ? "" : "disabled"}>Upgrade to ×${RULES.levelMult(lv + 1)} for ${up.toLocaleString()} ◆</button>`)
        : !open ? `<div class="muted small">🔒 Unlock ${req.name} first</div>` :
      `<button id="skBuy" class="btn-gold" ${chips >= price ? "" : "disabled"}>Buy for ${price.toLocaleString()} ◆ chips</button>`);
    if ($("skBuy")) $("skBuy").onclick = () => buySkill(s.id);
    if ($("skUp")) $("skUp").onclick = () => upgradeSkill(s.id);
  }
  function buySkill(id) {
    const s = RULES.SKILLS.find((k) => k.id === id);
    if (!RULES.canBuy(skills, id, chips)) { $("skStatus").innerHTML = `<span class="lose-txt">Need ${RULES.skillChipCost(s).toLocaleString()} ◆ chips — build your casino</span>`; return; }
    skills = [...skills, id];
    store.set({ skills });
    setChips(chips - RULES.skillChipCost(s));
    updBonus();
    $("skStatus").innerHTML = `<span class="win-txt">Unlocked ${s.name}!</span>`;
    renderSkills();
  }

  function upgradeSkill(id) {
    const s = RULES.SKILLS.find((k) => k.id === id), up = RULES.upgradeCost(id, skillLv);
    if (up == null || !skills.includes(id)) return;
    if (chips < up) { $("skStatus").innerHTML = `<span class="lose-txt">Need ${up.toLocaleString()} ◆ chips</span>`; return; }
    skillLv = { ...skillLv, [id]: RULES.level(skillLv, id) + 1 };
    store.set({ skillLv });
    setChips(chips - up);
    updBonus();
    $("skStatus").innerHTML = `<span class="win-txt">${s.name} is now level ${skillLv[id]}!</span>`;
    renderSkills();
  }

  // ---------- casino tycoon ----------
  function setChips(n) {
    chips = Math.max(0, n);
    $("chipBal").textContent = cfmt(chips);
    store.set({ chips, casinoAt: (casinoAt = Date.now()) });
  }
  function renderCasino() {
    const rate = RULES.chipRate(casino);
    $("chipRate").textContent = (rate < 10 ? rate.toFixed(1) : cfmt(rate)) + "/s";
    $("casinoChips").textContent = cfmt(chips);
    renderFloor();
    $("upList").innerHTML = RULES.UPGRADES.map((u) => {
      const own = RULES.hasUp(casino, u.id);
      return `<div class="biz${own ? " owned" : ""}"><span class="biz-ic">${u.icon}</span><div class="biz-main"><b>${u.name}</b>
        <div class="small muted">${u.desc}</div></div>${own ? `<span class="win-txt small">Owned</span>` :
        `<button class="btn-gold sm biz-buy" data-up="${u.id}" ${coins >= u.cost ? "" : "disabled"}>${cfmt(u.cost)} 🪙</button>`}</div>`;
    }).join("");
    $("upList").querySelectorAll("[data-up]").forEach((btn) => (btn.onclick = () => buyUpgrade(btn.dataset.up)));
    $("casinoList").innerHTML = RULES.BUILDINGS.map((b) => {
      const n = casino[b.id] || 0, cost = RULES.buildingCost(b.id, n);
      return `<div class="biz"><span class="biz-ic">${b.icon}</span><div class="biz-main"><b>${b.name}</b> <span class="muted small">×${n}</span>
        <div class="small muted">+${b.rate} ◆/s each</div></div>
        <button class="btn-gold sm biz-buy" data-biz="${b.id}" ${coins >= cost ? "" : "disabled"}>${cfmt(cost)} 🪙</button></div>`;
    }).join("");
    $("packList").innerHTML = RULES.PACKS.map((p) => `<div class="biz"><span class="biz-ic">${p.icon}</span><div class="biz-main"><b>${p.name}</b>
        <div class="small muted">Coins + ◆ chips</div></div><button class="btn-gold sm biz-buy" data-pack="${p.id}" ${coins >= p.cost ? "" : "disabled"}>${cfmt(p.cost)} 🪙</button></div>`).join("");
    $("packList").querySelectorAll("[data-pack]").forEach((btn) => (btn.onclick = () => buyPack(btn.dataset.pack)));
    $("casinoList").querySelectorAll("[data-biz]").forEach((btn) => (btn.onclick = () => buyBuilding(btn.dataset.biz)));
  }
  function buyPack(id) {
    const p = RULES.PACKS.find((k) => k.id === id);
    if (!p || coins < p.cost) return;
    const r = RULES.openPack(id);
    setCoins(coins - p.cost + r.coins);
    setChips(chips + r.chips);
    const it = RULES.item(r.item);
    setInv([...inv, r.item]);
    $("packResult").innerHTML = `<div class="pack-pop r-${r.rarity}"><b>${r.name}!</b><span class="pack-item">${it.icon} ${it.name}</span><span>+${cfmt(r.coins)} 🪙 · +${cfmt(r.chips)} ◆</span></div>`;
    renderCasino();
  }
  // The casino floor: every place you own shows up, upgrades decorate it.
  function renderFloor() {
    const total = RULES.BUILDINGS.reduce((n, b) => n + (casino[b.id] || 0), 0);
    const tiles = [];
    for (const b of RULES.BUILDINGS) {
      const n = casino[b.id] || 0;
      for (let i = 0; i < Math.min(n, 12); i++) tiles.push(`<span class="fl-t" title="${b.name}" style="animation-delay:${(tiles.length % 7) * 0.3}s">${b.icon}</span>`);
      if (n > 12) tiles.push(`<span class="fl-more">+${n - 12}</span>`);
    }
    const ups = RULES.UPGRADES.filter((u) => RULES.hasUp(casino, u.id)).map((u) => u.icon).join(" ");
    const guests = Math.min(8, Math.ceil(total / 3));
    $("floor").className = "floor" + (RULES.hasUp(casino, "neon") ? " neon" : "") + (RULES.hasUp(casino, "penthouse") ? " lux" : "");
    $("floor").innerHTML = `<div class="fl-sign">${RULES.hasUp(casino, "neon") ? "✨ " : ""}${esc(me.name || "My")}'s Casino${ups ? ` <span class="fl-ups">${ups}</span>` : ""}</div>
      <div class="fl-grid">${tiles.join("") || `<span class="muted small">Empty floor — buy a Slot Machine to open!</span>`}</div>
      <div class="fl-guests">${"🚶".repeat(guests)}</div>`;
  }
  function buyUpgrade(id) {
    const u = RULES.UPGRADES.find((k) => k.id === id);
    if (!u || RULES.hasUp(casino, id) || coins < u.cost) return;
    casino = { ...casino, ["up_" + id]: 1 };
    store.set({ casino });
    setCoins(coins - u.cost);
    renderCasino();
  }
  function buyBuilding(id) {
    const n = casino[id] || 0, cost = RULES.buildingCost(id, n);
    if (coins < cost) return;
    casino = { ...casino, [id]: n + 1 };
    store.set({ casino });
    setCoins(coins - cost);
    renderCasino();
  }
  // Earn chips every second while the game is open.
  setInterval(() => {
    const rate = RULES.chipRate(casino);
    if (!rate) return;
    setChips(chips + rate);
    if (!$("casino").hidden) renderCasino();
    if (!$("skills").hidden && Math.floor(chips) !== Math.floor(chips - rate)) renderSkills();
  }, 1000);

  // ---------- secret owner panel ----------
  // Unlock: tap a coin logo, then flip with a bet of 0 three times, then enter the password.
  let ownerPw = "";
  const PASS_HASH = "6d82ddbfde2dea4f3d91810dbd274c8132a86446a4a2b7b0c28d08db9971917e";
  const secret = { armedAt: 0, zeros: 0 };
  const arm = () => { secret.armedAt = Date.now(); secret.zeros = 0; };
  $("brandLogo").addEventListener("click", arm);
  $("flipCoin").addEventListener("click", arm);
  // Returns true when this flip press was part of the secret sequence.
  function secretStep(raw) {
    const live = secret.armedAt && Date.now() - secret.armedAt < 30000;
    if (!live || raw === "" || +raw !== 0) { secret.armedAt = 0; secret.zeros = 0; return false; }
    secret.zeros++;
    secret.armedAt = Date.now();
    if (secret.zeros < 3) return false; // looks like a normal "Not enough coins"
    secret.armedAt = 0; secret.zeros = 0;
    $("bet").value = 10;
    $("flipResult").textContent = "";
    $("ownerPass").value = "";
    $("ownerErr").hidden = true;
    show("ownerGate");
    setTimeout(() => $("ownerPass").focus(), 0);
    return true;
  }
  async function sha256(text) {
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
    return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  $("ownerForm").onsubmit = async (e) => {
    e.preventDefault();
    const pw = $("ownerPass").value;
    const ok = (await sha256(pw)) === PASS_HASH;
    if (ok) ownerPw = pw;
    $("ownerPass").value = "";
    if (!ok) { $("ownerErr").hidden = false; return; }
    openOwner();
  };
  $("ownerCancel").onclick = () => show("home");

  function saveOwner() { store.set({ owner }); applyOwner(); track(); submitScore(); }
  function applyOwner() {
    const ch = $("chance");
    ch.max = owner.wide ? 99 : 50;
    if (+ch.value > +ch.max) ch.value = ch.max;
    updMult();
    $("oLuck").value = owner.luck;
    $("oLuckTxt").textContent = luckLabel(owner.luck);
    $("luckBadge").hidden = !(owner.luck > 0);
    $("luckBadge").textContent = `🍀 Luck ${luckLabel(owner.luck)}`;
    $("oShield").checked = owner.shield;
    $("oChance").checked = owner.wide;
    $("oCrown").checked = owner.crown;
  }
  function openOwner() { $("oBal").textContent = coins.toLocaleString(); applyOwner(); renderTargets(); renderBanTargets(); loadBans(); $("oPStatus").textContent = "Above 0 helps them win flips and keep coins in duels. Below 0 makes their flips lose more."; show("owner"); }

  // ----- other players' luck -----
  function renderTargets() {
    const sel = $("oTarget"), cur = sel.value;
    const ids = Object.keys(online).sort((a, b) => online[a].name.localeCompare(online[b].name));
    sel.innerHTML = ids.length
      ? ids.map((id) => `<option value="${esc(id)}">${esc(online[id].name)} · luck ${luckLabel(online[id].luck)}</option>`).join("")
      : `<option value="">Nobody else is online</option>`;
    if (cur && online[cur]) sel.value = cur;
    sel.disabled = $("oSendLuck").disabled = $("oResetLuck").disabled = $("oResetAll").disabled = !ids.length;
    if (!sel.dataset.touched && sel.value && online[sel.value]) setPLuck(online[sel.value].luck);
  }
  function setPLuck(n) { $("oPLuck").value = n; $("oPLuckTxt").textContent = luckLabel(+n); }
  $("oTarget").onchange = () => { $("oTarget").dataset.touched = ""; delete $("oTarget").dataset.touched; const p = online[$("oTarget").value]; if (p) setPLuck(p.luck); };
  $("oPLuck").oninput = () => { $("oTarget").dataset.touched = "1"; setPLuck($("oPLuck").value); };
  function giveLuck(id, n) {
    send(id, { t: "luck", luck: n });
    online[id].luck = n;
  }
  $("oSendLuck").onclick = () => {
    const id = $("oTarget").value, p = online[id];
    if (!p) { $("oPStatus").textContent = "That player just went offline."; return; }
    const n = clampLuck($("oPLuck").value);
    giveLuck(id, n);
    delete $("oTarget").dataset.touched;
    renderTargets();
    $("oPStatus").innerHTML = `<span class="win-txt">${esc(p.name)}'s luck is now ${luckLabel(n)}.</span>`;
  };
  // Undo luck an owner panel gave someone (back to normal odds).
  $("oResetLuck").onclick = () => {
    const id = $("oTarget").value, p = online[id];
    if (!p) { $("oPStatus").textContent = "That player just went offline."; return; }
    giveLuck(id, 0);
    delete $("oTarget").dataset.touched;
    renderTargets();
    setPLuck(0);
    $("oPStatus").innerHTML = `<span class="win-txt">${esc(p.name)}'s luck is back to normal.</span>`;
  };
  $("oResetAll").onclick = () => {
    // Send to everyone: their real luck may not have reached this window yet, and 0 is harmless.
    const ids = Object.keys(online);
    ids.forEach((id) => giveLuck(id, 0));
    delete $("oTarget").dataset.touched;
    renderTargets();
    setPLuck(0);
    $("oPStatus").innerHTML = ids.length
      ? `<span class="win-txt">Luck is back to normal for everyone online (${ids.length} player${ids.length > 1 ? "s" : ""}).</span>`
      : "Nobody else is online right now.";
  };
  const oAmt = () => Math.max(0, Math.floor(+$("oAmount").value) || 0);
  const ownerCoins = (n) => { setCoins(n); $("oBal").textContent = coins.toLocaleString(); };
  document.querySelectorAll("[data-amt]").forEach((b) => (b.onclick = () => ($("oAmount").value = b.dataset.amt)));
  $("oGive").onclick = () => ownerCoins(Math.min(coins + oAmt(), Number.MAX_SAFE_INTEGER));
  $("oTake").onclick = () => ownerCoins(coins - oAmt());
  $("oSet").onclick = () => ownerCoins(Math.min(oAmt(), Number.MAX_SAFE_INTEGER));
  $("oReset").onclick = () => ownerCoins(100);
  $("oLuck").oninput = () => { owner.luck = +$("oLuck").value; saveOwner(); };
  $("oShield").onchange = () => { owner.shield = $("oShield").checked; saveOwner(); };
  $("oChance").onchange = () => { owner.wide = $("oChance").checked; saveOwner(); };
  $("oCrown").onchange = () => { owner.crown = $("oCrown").checked; saveOwner(); };
  $("oLock").onclick = () => { owner = { luck: 0, shield: false, wide: false, crown: false }; saveOwner(); show("home"); };
  $("ownerClose").onclick = () => show("home");
  // ----- bans (checked on the server with the owner password) -----
  let banned = new Set();
  async function loadBans() {
    try {
      const { data, error } = await getSb().from("banned_players").select("id,name").order("banned_at", { ascending: false });
      if (error) return;
      banned = new Set(data.map((r) => r.id));
      if (banned.has(me.id)) return kickBanned();
      $("oBanList").innerHTML = data.length
        ? data.map((r) => `<div class="o-row"><span class="small">🚫 ${esc(r.name)}</span><button class="btn-ghost sm" data-unban="${esc(r.id)}" data-name="${esc(r.name)}">Unban</button></div>`).join("")
        : `<p class="muted small">Nobody is banned.</p>`;
      $("oBanList").querySelectorAll("[data-unban]").forEach((b) => (b.onclick = () => setBan(b.dataset.unban, b.dataset.name, false)));
      renderBanTargets();
      if (lobby) onSync();
    } catch {}
  }
  function renderBanTargets() {
    const ids = Object.keys(online);
    $("oBanTarget").innerHTML = ids.length
      ? ids.map((id) => `<option value="${esc(id)}">${esc(online[id].name)}</option>`).join("")
      : `<option value="">Nobody else online</option>`;
    $("oBan").disabled = !ids.length;
  }
  async function setBan(id, name, on) {
    if (!ownerPw) { $("oBanStatus").textContent = "Lock and unlock the panel again to ban players."; return; }
    const { error } = await getSb().rpc("set_ban", { p_password: ownerPw, p_id: id, p_name: name, p_banned: on });
    if (error) { $("oBanStatus").innerHTML = `<span class="lose-txt">Couldn't do that. Try again.</span>`; return; }
    if (on) send(id, { t: "ban" });
    $("oBanStatus").innerHTML = `<span class="win-txt">${esc(name)} is ${on ? "banned" : "unbanned"}.</span>`;
    loadBans();
  }
  $("oBan").onclick = () => {
    const id = $("oBanTarget").value, p = online[id];
    if (!p) { $("oBanStatus").textContent = "That player just went offline."; return; }
    if (confirm(`Ban ${p.name}?`)) setBan(id, p.name, true);
  };
  function kickBanned() {
    try { if (lobby) getSb().removeChannel(lobby); } catch {}
    lobby = null;
    clearTimeout(submitScore.t);
    document.body.innerHTML = `<div class="panel center" style="padding:40px 20px"><div class="lock-emoji">🚫</div><h2 class="o-title">You're banned</h2><p class="muted">The owner banned you from Pocket Coins.</p></div>`;
  }
  setInterval(loadBans, 30000);

  // ---------- lobby ----------
  // The lobby allows only a few presence updates per 10 seconds, so updates are
  // throttled (min 3s apart, latest value wins) and skipped when nothing changed.
  let lastTrackAt = 0, lastTracked = "";
  function track() {
    if (!lobby || !lobbyReady) return;
    clearTimeout(track.t);
    const wait = Math.max(0, lastTrackAt + 3000 - Date.now());
    track.t = setTimeout(() => {
      if (!lobby || !lobbyReady) return;
      const data = { name: me.name || "Player", coins, busy: !!(duel && !duel.ended) || !!outgoing, crown: owner.crown, luck: given };
      const json = JSON.stringify(data);
      if (json === lastTracked) return;
      lastTracked = json;
      lastTrackAt = Date.now();
      lobby.track(data);
    }, wait);
  }
  function send(to, msg) {
    if (!lobby) return;
    lobby.send({ type: "broadcast", event: "msg", payload: { ...msg, to, from: me.id } });
  }
  const hue = (s) => [...s].reduce((h, ch) => (h * 31 + ch.charCodeAt(0)) % 360, 7);

  function renderPlayers() {
    const ids = Object.keys(online).sort((a, b) => online[a].name.localeCompare(online[b].name));
    $("onlineCount").textContent = ids.length;
    if (!ids.length) {
      $("plist").innerHTML = `<div class="empty">Nobody else is online right now.<br>Players show up here the moment they open Pocket Coins.</div>`;
      return;
    }
    $("plist").innerHTML = ids.map((id) => {
      const p = online[id];
      return `<div class="player ${p.busy ? "busy" : ""}">
        <div class="avatar" style="background:hsl(${hue(id)} 80% 72%)">${esc((p.name || "?")[0].toUpperCase())}</div>
        <div class="pinfo"><div class="pname">${esc(p.name)}${p.crown ? `<span class="crown" title="Owner">👑</span>` : ""}</div>
          <div class="pmeta"><span class="online-dot"></span>${p.busy ? "In a duel" : "Online"} · ${p.coins} coins</div></div>
        <button class="duel-btn" data-id="${esc(id)}" ${p.busy ? "disabled" : ""}>Duel</button>
      </div>`;
    }).join("");
  }
  $("plist").onclick = (e) => {
    const b = e.target.closest(".duel-btn");
    if (!b || b.disabled || duel) return;
    openSetup(b.dataset.id);
  };

  function renderInvites() {
    const show = !duel || duel.ended;
    $("invites").innerHTML = !show ? "" : [...invites.entries()].map(([id, inv]) => {
      const g = GAMES[inv.game];
      return `<div class="invite" data-id="${esc(id)}">
        <div><b>${esc(inv.fromName)}</b> wants to duel: ${g.emoji} <b>${g.name}</b> for <b>${inv.bet}</b> coins</div>
        <div class="invite-actions"><button class="accept">Accept</button><button class="decline">No thanks</button></div>
      </div>`;
    }).join("");
  }
  $("invites").onclick = (e) => {
    const card = e.target.closest(".invite");
    if (!card) return;
    const id = card.dataset.id, inv = invites.get(id);
    if (!inv) return;
    if (e.target.closest(".decline")) { dropInvite(id, true); return; }
    if (e.target.closest(".accept")) {
      if (inv.bet > coins) { notice(`You need ${inv.bet} coins to accept that duel.`); dropInvite(id, true); return; }
      if (outgoing) cancelOutgoing();
      const seed = Math.floor(Math.random() * 2 ** 31);
      send(inv.from, { t: "accept", id, seed });
      invites.delete(id); clearTimeout(inv.timer);
      for (const other of [...invites.keys()]) dropInvite(other, true);
      startDuel({ id, game: inv.game, bet: inv.bet, foeId: inv.from, foeName: inv.fromName, side: 1, seed });
    }
  };
  function dropInvite(id, tellThem) {
    const inv = invites.get(id);
    if (!inv) return;
    clearTimeout(inv.timer);
    invites.delete(id);
    if (tellThem) send(inv.from, { t: "decline", id });
    renderInvites();
  }

  // ---------- setup / outgoing invites ----------
  function openSetup(id) {
    target = id;
    $("setupFoe").textContent = online[id]?.name || "Player";
    $("gamePick").innerHTML = Object.entries(GAMES).map(([key, g]) =>
      `<button class="game-card ${key === pickedGame ? "on" : ""}" data-g="${key}"><span class="emo">${g.emoji}</span><b>${g.name}</b><span>${g.desc}</span></button>`).join("");
    $("duelBet").value = Math.max(1, Math.min(+$("duelBet").value || 10, coins || 1));
    $("setupStatus").textContent = "";
    show("setup");
  }
  $("gamePick").onclick = (e) => {
    const c = e.target.closest(".game-card");
    if (!c) return;
    pickedGame = c.dataset.g;
    $("gamePick").querySelectorAll(".game-card").forEach((x) => x.classList.toggle("on", x === c));
  };
  $("setupBack").onclick = () => { target = null; show("home"); };
  $("sendInvite").onclick = async () => {
    const p = online[target];
    const bet = Math.floor(+$("duelBet").value);
    if (!p) { $("setupStatus").textContent = "That player just went offline."; return; }
    // Prevent inviting banned users
    if (window.PC_BAN && window.PC_BAN.isBanned) {
      const banned = await window.PC_BAN.isBanned(p.id);
      if (banned) { $("setupStatus").textContent = `${p.name} is banned and cannot be invited.`; return; }
    }
    if (p.busy) { $("setupStatus").textContent = "They're in another duel right now."; return; }
    if (!(bet >= 1)) { $("setupStatus").textContent = "Bet at least 1 coin."; return; }
    if (bet > coins) { $("setupStatus").textContent = "You don't have that many coins."; return; }
    if (bet > p.coins) { $("setupStatus").textContent = `${p.name} only has ${p.coins} coins.`; return; }
    outgoing = { id: rid(), to: target, toName: p.name, game: pickedGame, bet };
    outgoing.timer = setTimeout(() => { cancelOutgoing(); notice(`${esc(p.name)} didn't answer.`); }, 30000);
    send(target, { t: "invite", id: outgoing.id, game: pickedGame, bet, fromName: me.name || "Player" });
    $("waitFoe").textContent = p.name;
    show("waiting");
    track();
  };
  function cancelOutgoing(silent) {
    if (!outgoing) return;
    clearTimeout(outgoing.timer);
    if (!silent) send(outgoing.to, { t: "cancel", id: outgoing.id });
    outgoing = null;
    if (!duel) { show("home"); tab("players"); }
    track();
  }
  $("cancelInvite").onclick = () => cancelOutgoing();

  // ---------- duels ----------
  // The duel is saved (with a heartbeat) so leaving mid-duel counts as giving up,
  // while another open Pocket Coins window sharing these coins leaves it alone.
  function beat() {
    if (duel && !duel.ended) store.set({ activeDuel: { id: duel.id, bet: duel.bet, at: Date.now() } });
    else clearInterval(beat.t);
  }
  function startDuel(d) {
    duel = { ...d, ended: false };
    beat();
    clearInterval(beat.t);
    beat.t = setInterval(beat, 5000);
    const g = GAMES[d.game];
    $("duelGame").textContent = `${g.emoji} ${g.name}`;
    $("duelFoe").textContent = d.foeName;
    $("duelBetTxt").textContent = d.bet;
    $("duelStatus").textContent = "";
    $("forfeit").hidden = false;
    $("stage").innerHTML = "";
    $("stage").onclick = $("stage").onmousemove = $("stage").onmouseleave = null;
    show("duel");
    renderInvites();
    track();
    const id = d.id;
    duel.handle = g.start({
      el: $("stage"), side: d.side, seed: d.seed, foe: d.foeName,
      send: (move) => { if (duel && duel.id === id && !duel.ended) send(d.foeId, { t: "move", id, move }); },
      end: (res) => endDuel(id, res),
      status: (html) => { if (duel && duel.id === id) $("duelStatus").innerHTML = html; },
    });
  }
  function endDuel(id, res, reason) {
    if (!duel || duel.id !== id || duel.ended) return;
    duel.ended = true;
    clearInterval(beat.t);
    store.remove("activeDuel");
    let saved = false;
    if (res > 0) setCoins(coins + duel.bet + Math.floor(duel.bet * perks().duelBonus));
    else if (res < 0 && !owner.shield) {
      saved = luck() > 0 && Math.random() * 100 < luck();
      if (!saved) setCoins(coins - duel.bet + Math.floor(duel.bet * perks().duelRefund));
    }
    $("forfeit").hidden = true;
    const d = duel;
    setTimeout(() => {
      if (duel !== d) return;
      $("overEmoji").textContent = res > 0 ? "🏆" : res < 0 ? "💸" : "🤝";
      $("overTitle").textContent = res > 0 ? "You won!" : res < 0 ? "You lost" : "It's a tie";
      $("overText").innerHTML = (reason ? reason + " " : "") +
        (res > 0 ? `<span class="win-txt">+${d.bet} coins</span>`
          : res < 0 && (saved || owner.shield) ? `<span class="win-txt">🍀 Lucky! You kept your coins.</span>`
          : res < 0 ? `<span class="lose-txt">−${d.bet} coins</span>` : "No coins changed hands.");
      show("over");
      track();
    }, reason ? 0 : 1600);
  }
  $("forfeit").onclick = () => {
    if (!duel || duel.ended) return;
    send(duel.foeId, { t: "quit", id: duel.id });
    endDuel(duel.id, -1, "You gave up.");
  };
  $("overBack").onclick = () => { duel = null; show("home"); tab("players"); renderInvites(); renderPlayers(); track(); };

  function onMsg(m) {
    if (!m || m.to !== me.id || !m.from) return;
    if (m.t === "invite") {
      if (!GAMES[m.game] || !(m.bet >= 1)) return;
      // Ignore invites from banned users
      if (window.PC_BAN && window.PC_BAN.isBanned) {
        window.PC_BAN.isBanned(m.from).then((banned) => {
          if (banned) return;
          // Process invite as usual
          if ((duel && !duel.ended) || invites.has(m.id)) { send(m.from, { t: "decline", id: m.id }); return; }
          const inv = { from: m.from, fromName: String(m.fromName || "Player").slice(0, 16), game: m.game, bet: Math.floor(m.bet) };
          inv.timer = setTimeout(() => dropInvite(m.id, false), 30000);
          invites.set(m.id, inv);
          renderInvites();
        });
        return;
      }
      // Process invite as usual
      if ((duel && !duel.ended) || invites.has(m.id)) { send(m.from, { t: "decline", id: m.id }); return; }
      const inv = { from: m.from, fromName: String(m.fromName || "Player").slice(0, 16), game: m.game, bet: Math.floor(m.bet) };
      inv.timer = setTimeout(() => dropInvite(m.id, false), 30000);
      invites.set(m.id, inv);
      renderInvites();
    } else if (m.t === "cancel") {
      dropInvite(m.id, false);
    } else if (m.t === "decline") {
      if (outgoing && outgoing.id === m.id) { const n = outgoing.toName; cancelOutgoing(true); notice(`${esc(n)} said no thanks.`); }
    } else if (m.t === "accept") {
      if (outgoing && outgoing.id === m.id && outgoing.to === m.from) {
        const o = outgoing;
        clearTimeout(o.timer);
        outgoing = null;
        startDuel({ id: o.id, game: o.game, bet: o.bet, foeId: o.to, foeName: o.toName, side: 0, seed: m.seed | 0 });
      } else send(m.from, { t: "quit", id: m.id });
    } else if (m.t === "move") {
      if (duel && duel.id === m.id && !duel.ended && m.from === duel.foeId) duel.handle?.onMove(m.move || {});
    } else if (m.t === "ban") {
      loadBans();
    } else if (m.t === "luck") {
      given = clampLuck(m.luck);
      store.set({ luck: given });
      track();
    } else if (m.t === "quit") {
      if (duel && duel.id === m.id && !duel.ended) endDuel(m.id, 1, `${esc(duel.foeName)} gave up.`);
    }
  }

  function onSync() {
    const state = lobby.presenceState();
    online = {};
    for (const [key, metas] of Object.entries(state)) {
      if (key === me.id || !metas.length || banned.has(key)) continue;
      const p = metas[metas.length - 1];
      online[key] = { name: String(p.name || "Player").slice(0, 16), coins: Math.floor(+p.coins || 0), busy: !!p.busy, crown: p.crown === true, luck: clampLuck(p.luck) };
    }
    renderPlayers();
    if (!$("owner").hidden) { renderTargets(); renderBanTargets(); }
    // Presence updates can briefly drop a player, so only act if they're still gone a few seconds later.
    clearTimeout(onSync.t);
    onSync.t = setTimeout(checkGone, 4000);
  }
  function checkGone() {
    for (const [id, inv] of invites) if (!online[inv.from]) dropInvite(id, false);
    if (outgoing && !online[outgoing.to]) { const n = outgoing.toName; cancelOutgoing(true); notice(`${esc(n)} went offline.`); }
    if (duel && !duel.ended && !online[duel.foeId]) endDuel(duel.id, 1, `${esc(duel.foeName)} left the duel.`);
  }

  let sb = null;
  const getSb = () => sb || (sb = window.supabase.createClient(window.PC_CONFIG.url, window.PC_CONFIG.key, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  }));

  // ---------- leaderboard ----------
  // Each player's row is keyed by the hash of their private id (me.secret), so only they can update it.
  // Saves are throttled to one every 10s (latest value wins).
  let lbSent = "", lbAt = 0;
  function submitScore() {
    if (!me.secret) return;
    clearTimeout(submitScore.t);
    const wait = Math.max(0, lbAt + 10000 - Date.now());
    submitScore.t = setTimeout(async () => {
      const row = { p_secret: me.secret, p_name: me.name || "Player", p_coins: coins, p_crown: !!owner.crown };
      const json = JSON.stringify(row);
      if (json === lbSent) return;
      lbAt = Date.now();
      try {
        const { error } = await getSb().rpc("submit_score", row);
        if (!error) { lbSent = json; if (!$("top").hidden) loadTop(); }
      } catch {}
    }, wait);
  }
  const medal = (i) => ["🥇", "🥈", "🥉"][i] || `#${i + 1}`;
  function lbRow(rank, id, name, n, crown) {
    const mine = id === me.id, live = mine || !!online[id];
    return `<div class="player lb-row ${mine ? "me" : ""}">
      <div class="rank">${rank}</div>
      <div class="avatar" style="background:hsl(${hue(id)} 80% 72%)">${esc((name || "?")[0].toUpperCase())}</div>
      <div class="pinfo">
        <div class="pname">${esc(name)}${crown ? `<span class="crown" title="Owner">👑</span>` : ""}${mine ? ` <span class="you">you</span>` : ""}</div>
        <div class="pid-row muted small" title="Click to copy ID" onclick="navigator.clipboard.writeText('${esc(id)}').then(() => this.classList.add('copied'), setTimeout(() => this.classList.remove('copied'), 2000))">
          ID: ${esc(id.slice(0, 8))}… <span class="copy-hint">📋</span>
        </div>
        <div class="pmeta">${live ? `<span class="online-dot"></span>Online` : "Offline"}</div>
      </div>
      <div class="lb-coins"><span class="dot"></span>${cfmt(n)}</div>
    </div>`;
  }
  async function loadTop() {
    clearTimeout(loadTop.t);
    if ($("top").hidden) return;
    loadTop.t = setTimeout(loadTop, 15000);
    try {
      const db = getSb();
      const [top, above] = await Promise.all([
        db.from("leaderboard").select("id,name,coins,crown").order("coins", { ascending: false }).order("updated_at").limit(20),
        db.from("leaderboard").select("id", { count: "exact", head: true }).gt("coins", coins),
      ]);
      if (top.error) throw top.error;
      const rows = top.data || [];
      $("lbList").innerHTML = rows.length
        ? rows.map((r, i) => r.id === me.id
            ? lbRow(medal(i), r.id, me.name, coins, owner.crown)
            : lbRow(medal(i), r.id, r.name, r.coins, r.crown)).join("")
        : `<div class="empty">No one's on the board yet.</div>`;
      const inTop = rows.some((r) => r.id === me.id);
      // Players still on the starting 100 coins aren't saved to the board until they play.
      const fresh = coins === 100 && !owner.crown;
      $("lbMe").innerHTML = inTop || above.error ? ""
        : lbRow(`#${(above.count || 0) + 1}`, me.id, me.name, coins, owner.crown)
          + (fresh ? `<p class="muted small">Play a flip or a duel to get on the board.</p>` : "");
    } catch {
      $("lbList").innerHTML = `<div class="empty">Couldn't load the leaderboard. Trying again soon.</div>`;
    }
  }

  function connect() {
    getSb();
    const ch = sb.channel("pocket-coins-lobby", { config: { presence: { key: me.id }, broadcast: { self: false } } });
    lobby = ch;
    ch.on("presence", { event: "sync" }, () => { if (lobby === ch) onSync(); })
      .on("broadcast", { event: "msg" }, ({ payload }) => { if (lobby === ch) onMsg(payload); })
      .subscribe((status) => {
        if (lobby !== ch) return;
        if (status === "SUBSCRIBED") {
          lobbyReady = true;
          lastTracked = "";
          $("pStatus").textContent = IS_WEB
            ? "Keep this page open to get duel invites. Players on the website and the extension can duel each other."
            : "Keep Pocket Coins open to get duel invites. Tip: ⧉ opens it in its own window.";
          track();
        } else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
          lobbyReady = false;
          $("pStatus").textContent = "Reconnecting to the lobby…";
          clearTimeout(connect.t);
          connect.t = setTimeout(() => { if (lobby === ch) { sb.removeChannel(ch); connect(); } }, 2000);
        }
      });
  }

  // ---------- name + pop-out ----------
  $("name").onchange = (e) => {
    me.name = e.target.value.trim().slice(0, 16) || me.name;
    e.target.value = me.name;
    store.set({ name: me.name });
    track();
    submitScore();
  };
  $("popout").onclick = () => {
    if (IN_EXT) return window.parent.postMessage({ source: "pc-game", op: "popout" }, "*");
    api.windows.create({ url: api.runtime.getURL("popup.html?win=1"), type: "popup", width: 380, height: 660 });
    window.close();
  };

  // ---------- boot ----------
  Promise.resolve(store.get(["coins", "name", "pid", "activeDuel", "owner", "luck", "bonusAt", "skills", "skillLv", "chips", "casino", "casinoAt", "inv"])).then(async (d) => {
    d = d || {};
    coins = typeof d.coins === "number" ? d.coins : 100;
    // pid stays private (it proves who owns a leaderboard row); others only see its hash.
    const pid = d.pid || rid();
    try { me.secret = pid; me.id = await sha256(pid); } catch { me.secret = ""; me.id = pid; }
    me.name = d.name || "Player" + Math.floor(100 + Math.random() * 900);
    store.set({ pid, name: me.name });
    $("name").value = me.name;
    if (d.owner && typeof d.owner === "object") owner = { ...owner, ...d.owner };
    given = clampLuck(d.luck);
    skills = Array.isArray(d.skills) ? d.skills.filter((x) => typeof x === "string") : [];
    skillLv = d.skillLv && typeof d.skillLv === "object" ? d.skillLv : {};
    casino = d.casino && typeof d.casino === "object" ? d.casino : {};
    inv = Array.isArray(d.inv) ? d.inv.filter((x) => RULES.item(x)) : [];
    const away = RULES.offlineChips(casino, typeof d.casinoAt === "number" ? d.casinoAt : 0, Date.now());
    setChips((typeof d.chips === "number" ? d.chips : 0) + away);
    if (away >= 1) setTimeout(() => notice(`Your casino made ${cfmt(away)} ◆ chips while you were away.`), 300);
    bonusAt = typeof d.bonusAt === "number" && d.bonusAt <= Date.now() ? d.bonusAt : 0;
    applyOwner();
    const liveElsewhere = d.activeDuel && d.activeDuel.at && Date.now() - d.activeDuel.at < 15000;
    if (liveElsewhere) { /* a duel is running in another Pocket Coins window */ }
    else if (d.activeDuel && d.activeDuel.bet && owner.shield) store.remove("activeDuel");
    else if (d.activeDuel && d.activeDuel.bet) {
      coins = Math.max(0, coins - d.activeDuel.bet);
      store.remove("activeDuel");
      notice(`You left a duel early and lost ${d.activeDuel.bet} coins.`);
    }
    updMult();
    setCoins(coins);
    renderPlayers();
    await loadBans();
    if (banned.has(me.id)) return;
    connect();
  });
  // Coins, name and owner perks changed in another Pocket Coins window (extension or website).
  store.onChange((changes) => {
    if (changes.coins && typeof changes.coins.newValue === "number" && changes.coins.newValue !== coins) {
      coins = Math.max(0, Math.floor(changes.coins.newValue));
      $("bal").textContent = coins;
      updBonus();
      if (!$("owner").hidden) $("oBal").textContent = coins.toLocaleString();
      track();
    }
    if (changes.name && typeof changes.name.newValue === "string" && changes.name.newValue !== me.name) {
      me.name = changes.name.newValue.slice(0, 16);
      $("name").value = me.name;
      track();
    }
    if (changes.skills && Array.isArray(changes.skills.newValue)) { skills = changes.skills.newValue; updBonus(); if (!$("skills").hidden) renderSkills(); }
    if (changes.luck) { given = clampLuck(changes.luck.newValue); track(); }
    if (changes.bonusAt && typeof changes.bonusAt.newValue === "number") { bonusAt = changes.bonusAt.newValue; updBonus(); }
    if (changes.owner && changes.owner.newValue && typeof changes.owner.newValue === "object") {
      owner = { luck: 0, shield: false, wide: false, crown: false, ...changes.owner.newValue };
      applyOwner();
      track();
    }
  });

  window.addEventListener("pagehide", () => { try { lobby && lobby.untrack(); } catch {} });
})();
